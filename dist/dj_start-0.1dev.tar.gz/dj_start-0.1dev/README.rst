django learning program
=======================

A small django project built for learning purposes.

Quick start
-----------
1. Run `python dj_start/manage.py syncdb`
2. Load Load fixtures with `python dj_start/manage.py loaddata survey.json`
3. Start the server with::

    python dj_start/manage.py runserver --settings=dj_start.settings.local

3. Enjoy