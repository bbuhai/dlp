A simple django app what can be used for simple surveys/questionaires.
